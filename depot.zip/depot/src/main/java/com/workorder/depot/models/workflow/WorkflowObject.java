package com.workorder.depot.models.workflow;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import lombok.*;

import java.util.Map;

@EqualsAndHashCode
@ToString
@Builder
@JsonAutoDetect
@AllArgsConstructor
public class WorkflowObject extends AbstractWorkflowObject {

    @Getter
    @Setter
    private String id;

    @Getter
    @Setter
    private String name;

    @Getter
    @Setter
    private String category;

    @Getter
    @Setter
    private String type;

    @Getter
    @Setter
    private String subType;

    @Getter
    @Setter
    private String createdBy;

    @Getter
    @Setter
    private String createdTimestamp;

    @Getter
    @Setter
    private String lastUpdatedBy;

    @Getter
    @Setter
    private String lastUpdatedTimestamp;

    @Getter
    @Setter
    private String version;

    @Getter
    @Setter
    private String status;

    @Getter
    @Setter
    private String subStatus;

    @Getter
    @Setter
    private String restRequestOperationDefinition;

    @Getter
    @Setter
    private Map<String, ? extends AbstractWorkflowObject> workflowObjects;

    /**
     * Need to add more fields for below
     * -- successConditions
     * -- failureConditions
     *
     * And remove
     * -- status
     * -- subStatus
     */

    @Builder(builderMethodName = "WorkflowObjectBuilder")
    public WorkflowObject(Map<String, String> inputs, Map<String, String> outputs, String dependsOn, String id, String name, String category, String type, String subType,
                          String createdBy, String createdTimestamp, String lastUpdatedBy, String lastUpdatedTimestamp, String version, String status, String subStatus,
                          String restRequestOperationDefinition, Map<String, ? extends AbstractWorkflowObject> workflowObjects){
        super(inputs, outputs, dependsOn);
        this.id = id;
        this.name = name;
        this.category = category;
        this.type = type;
        this.subType = subType;
        this.createdBy = createdBy;
        this.createdTimestamp = createdTimestamp;
        this.lastUpdatedBy = lastUpdatedBy;
        this.lastUpdatedTimestamp = lastUpdatedTimestamp;
        this.version = version;
        this.status = status;
        this.subStatus = subStatus;
        this.restRequestOperationDefinition = restRequestOperationDefinition;
        this.workflowObjects = workflowObjects;
    }

}