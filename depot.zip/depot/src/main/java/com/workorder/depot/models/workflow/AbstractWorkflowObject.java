package com.workorder.depot.models.workflow;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import lombok.*;

import java.util.Map;

@EqualsAndHashCode
@ToString
@JsonAutoDetect
@Builder(builderMethodName = "abstractWorkflowObjectBuilder")
@AllArgsConstructor
//@Builder
@NoArgsConstructor
public class AbstractWorkflowObject {

    @Getter
    @Setter
    private Map<String, String> inputs;

    @Getter
    @Setter
    private Map<String, String> outputs;

    @Getter
    @Setter
    private String dependsOn;

}
