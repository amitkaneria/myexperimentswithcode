package com.workorder.depot.models;

import lombok.Getter;
import lombok.Setter;

public class Version {

    @Getter
    @Setter
    private String majorVersion;

    @Getter
    @Setter
    private String minorVersion;

    @Getter
    @Setter
    private String patchVersion;

    @Getter
    @Setter
    private String draftVersion;

}