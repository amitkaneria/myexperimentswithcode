package com.workorder.depot.models.workflow;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import lombok.*;

import java.util.Map;

@EqualsAndHashCode
@ToString
@Builder
@JsonAutoDetect
public class RestRequestOperationDefinition {

//    private Authentication authentication;

    @Getter
    @Setter
    private String method;

    @Getter
    @Setter
    private String url;

    @Getter
    @Setter
    private Map<String, String> body;

    @Getter
    @Setter
    private Map<String, String> headers;
}