package com.workorder.depot.util.dataformat;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.yaml.YAMLFactory;

public class JacksonDataFormatFactory {

    public static ObjectMapper objectMapper(String type){
        ObjectMapper objectMapper = null;
        if(type != null && type.equalsIgnoreCase("yaml")){
            objectMapper = new ObjectMapper(new YAMLFactory());
        }else if(type != null && type.equalsIgnoreCase("json")){
            objectMapper = new ObjectMapper(new JsonFactory());
        }else {
            return null;
        }

        return objectMapper;
    }

    public static String toJson(Object o){
        String json = null;
        try {
            json = objectMapper("json").writerWithDefaultPrettyPrinter().writeValueAsString(o);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return json;
    }

//    public static <T> parseJson(String str){
//        String json = null;
//        try {
//            json = objectMapper("json").readValue(str, <T>.class);
//        } catch (JsonProcessingException e) {
//            e.printStackTrace();
//        }
//        return <T>;
//    }

    public static String toYaml(Object o){
        String json = null;
        try {
            json = objectMapper("yaml").writerWithDefaultPrettyPrinter().writeValueAsString(o);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return json;
    }


}