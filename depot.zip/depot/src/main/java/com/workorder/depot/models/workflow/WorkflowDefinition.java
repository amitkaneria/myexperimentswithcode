package com.workorder.depot.models.workflow;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import lombok.*;

import java.util.Map;

@EqualsAndHashCode
@ToString
@Builder
@JsonAutoDetect
public class WorkflowDefinition {

    @Getter
    @Setter
    private Map<String, WorkflowObject> workflowOperations;

    @Getter
    @Setter
    private Map<String, String> schedulerDetails;

    @Getter
    @Setter
    private Map<String, String> tags;

    @Getter
    @Setter
    private Map<String, String> metadata;
}