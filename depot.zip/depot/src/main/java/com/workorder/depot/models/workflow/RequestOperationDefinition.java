package com.workorder.depot.models.workflow;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import lombok.*;

import java.util.Map;

@EqualsAndHashCode
@ToString
@Builder
@JsonAutoDetect
@AllArgsConstructor
public class RequestOperationDefinition extends AbstractWorkflowObject {

    @Getter
    @Setter
    private RestRequestOperationDefinition restRequestOperationDefinition;

    @Builder(builderMethodName = "RequestOperationDefinitionBuilder")
    public RequestOperationDefinition(Map<String, String> inputs, Map<String, String> outputs, String dependsOn, RestRequestOperationDefinition restRequestOperationDefinition){
        super(inputs, outputs, dependsOn);
        this.restRequestOperationDefinition = restRequestOperationDefinition;
    }
}