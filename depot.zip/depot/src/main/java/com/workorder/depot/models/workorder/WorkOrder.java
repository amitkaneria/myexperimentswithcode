package com.workorder.depot.models.workorder;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import lombok.*;

import java.util.Date;
import java.util.Map;

@EqualsAndHashCode
@ToString
@Builder
@JsonAutoDetect
public class WorkOrder {

    @Getter
    @Setter
    private String id;

    @Getter
    @Setter
    private String groupId;

    @Getter
    @Setter
    private WorkOrderDefinition workOrderDefinition;

    @Getter
    @Setter
    private Map<String, Map<String, String>> inputs;

    @Getter
    @Setter
    private Map<String, Map<String, String>> outputs;

    @Getter
    @Setter
    private String createdBy;

    @Getter
    @Setter
    private String lastUpdatedBy;

    @Getter
    @Setter
    private Date createdTimestamp;

    @Getter
    @Setter
    private Date lastUpdatedTimestamp;

}