package com.workorder.depot.models;

import lombok.Getter;
import lombok.Setter;

public class User {

    @Getter
    @Setter
    private String id;

    @Getter
    @Setter
    private String groupId;

}