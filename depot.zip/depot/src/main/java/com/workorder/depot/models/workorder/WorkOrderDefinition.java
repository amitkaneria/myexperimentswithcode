package com.workorder.depot.models.workorder;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import lombok.*;

import java.util.Map;

@EqualsAndHashCode
@ToString
@Builder
@JsonAutoDetect
public class WorkOrderDefinition {

    @Getter
    @Setter
    private String id;

    @Getter
    @Setter
    private String version;

    @Getter
    @Setter
    private String groupId;

    @Getter
    @Setter
    private Map<String, Map<String, PropertyDefinition>> inputs;

    @Getter
    @Setter
    private Map<String, Map<String, PropertyDefinition>> outputs;
}