package com.workorder.depot.models.workorder;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import lombok.*;

import java.util.List;

@EqualsAndHashCode
@ToString
@Builder
@JsonAutoDetect
public class PropertyDefinition {

    @Getter
    @Setter
    private String name;

    @Getter
    @Setter
    private String regex;

    @Getter
    @Setter
    private List<String> values;
}