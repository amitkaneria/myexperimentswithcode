package com.workorder.depot.util.dataformat;

import com.workorder.depot.models.workorder.WorkOrderDefinition;
import org.junit.Test;

public class JacksonDataFormatFactoryTest {

    @Test
    public void test(){

        WorkOrderDefinition woDef = WorkOrderDefinition.builder()
                .groupId("MAIL_ORDER")
                .id("dasdawsdas")
                .version("1.0.0")
                .inputs(null)
                .outputs(null)
                .build();

        System.out.println(woDef);
        System.out.println(JacksonDataFormatFactory.toJson(woDef));
    }
}