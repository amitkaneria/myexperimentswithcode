package com.workorder.service.api;

import com.workorder.depot.models.workflow.*;
import com.workorder.depot.util.dataformat.JacksonDataFormatFactory;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

import javax.ws.rs.*;
import javax.ws.rs.core.Response;
import java.util.HashMap;
import java.util.Map;

@Api
@Path("/hello")
public class HelloWorldService {

    @POST
    @Path("/{param}")
    @Produces("application/json")
    public Response getMsg(@PathParam("param") String msg) {

        String output = "Hello,  " + msg + "!";
        return Response.status(200).entity(output).build();

    }

    @GET
    @Path("/{param}")
    @Produces("application/json")
    public Response postMessage(@PathParam("param") String msg, @QueryParam("type") String type) {

        System.out.println("Request received with msg:" + msg + " type:" + type);

        Map<String, String> metadata = new HashMap<>();
        metadata.put("test-metadata1", "test-metadata1");
        metadata.put("test-metadata2", "test-metadata2");
        metadata.put("test-metadata3", "test-metadata3");

        Map<String, String> schedulerDetails = new HashMap<>();
        schedulerDetails.put("schedule1", "*");
        schedulerDetails.put("schedule2", "7 2 23 60 0");

        Map<String, String> tags = new HashMap<>();
        tags.put("tag1", "tag1");
        tags.put("tag2", "tag2");

        RestRequestOperationDefinition restRequestOperation1Definition = RestRequestOperationDefinition.builder()
                .method("POST")
                .url("http://localhost:8080/service/rest/hello/Ruhi")
                .body(null)
                .headers(null)
                .build();

        RestRequestOperationDefinition restRequestOperation2Definition = RestRequestOperationDefinition.builder()
                .method("GET")
                .url("http://localhost:8080/service/rest/hello/xyz?type=yaml")
                .body(null)
                .headers(null)
                .build();

        RequestOperationDefinition requestOperation1Def = RequestOperationDefinition.builder()
                .restRequestOperationDefinition(restRequestOperation1Definition)
                .build();

        RequestOperationDefinition requestOperation2Def = RequestOperationDefinition.builder()
                .restRequestOperationDefinition(restRequestOperation2Definition)
                .dependsOn("operation1")
                .build();

        WorkflowObject workflow1 = WorkflowObject.builder()
                .category("category")
                .createdBy("Ruhi")
                .createdTimestamp(System.currentTimeMillis()+"")
                .id("id")
                .name("name")
                .status("status")
                .subStatus("substatus")
                .type("type")
                .version("1.0.0")
                .restRequestOperationDefinition("operation")
//                .workflowObjects(workflowObjects)
                .build();

        Map<String, AbstractWorkflowObject> workflowObjects = new HashMap<>();
        workflowObjects.put("operation1", requestOperation1Def);
        workflowObjects.put("operation2", requestOperation2Def);
        workflowObjects.put("workflow1", workflow1);

        WorkflowObject workflowObject = WorkflowObject.builder()
                .category("category")
                .createdBy("Ruhi")
                .createdTimestamp(System.currentTimeMillis()+"")
                .id("id")
                .name("name")
                .status("status")
                .subStatus("substatus")
                .type("type")
                .version("1.0.0")
                .restRequestOperationDefinition("operation")
                .workflowObjects(workflowObjects)
                .build();
        Map<String, WorkflowObject> workflowOperations = new HashMap<>();
        workflowOperations.put("test1", workflowObject);

        WorkflowDefinition workflowDefinition = WorkflowDefinition.builder()
                .metadata(metadata)
                .schedulerDetails(schedulerDetails)
                .tags(tags)
                .workflowOperations(workflowOperations)
                .build();

        String output = null;
        if(type != null && type.equalsIgnoreCase("json")){
            output = JacksonDataFormatFactory.toJson(workflowDefinition);
        }else {
            output = JacksonDataFormatFactory.toYaml(workflowDefinition);
        }

        return Response.status(200).entity(output).build();

    }
}