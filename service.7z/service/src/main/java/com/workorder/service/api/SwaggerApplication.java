package com.workorder.service.api;

import io.swagger.jaxrs.config.BeanConfig;

import javax.ws.rs.core.Application;
import java.util.HashSet;
import java.util.Set;

/**
 * This class is not needed for latest Swagger API Gen.
 * Swagger APIGen automatically detects the classes based on web.xml directory,
 * and generates swagger.json/swagger.yaml file
 */
public class SwaggerApplication extends Application {

    private static BeanConfig beanConfig = new BeanConfig();

    public SwaggerApplication() {
        beanConfig.setVersion("1.0");
        beanConfig.setSchemes(new String[] { "http" });
        beanConfig.setTitle("WorkOrder API");
        beanConfig.setBasePath("/service/rest");
        beanConfig.setResourcePackage("com.workorder.service.api");
        beanConfig.setScan(true);
    }

    @Override
    public Set<Class<?>> getClasses() {
        HashSet<Class<?>> set = new HashSet<Class<?>>();

        set.add(HelloWorldService.class);

        set.add(io.swagger.jaxrs.listing.ApiListingResource.class);
        set.add(io.swagger.jaxrs.listing.SwaggerSerializers.class);

        return set;
    }
}