package com.workorder.executor.models;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import lombok.*;

import java.util.Map;

@EqualsAndHashCode
@ToString
@Builder
@JsonAutoDetect
public class Operation {

    @Getter
    @Setter
    private String operationId;

    @Getter
    @Setter
    private String operationExecutionId;

    @Getter
    @Setter
    private Map<String, Request> requests;

    @Getter
    @Setter
    private Map<String, Response> responses;

}