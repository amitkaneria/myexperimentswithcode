package com.workorder.executor.models;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import lombok.*;

import java.util.Map;


@EqualsAndHashCode
@ToString
@Builder
@JsonAutoDetect
public class WorkflowInstance {

    @Getter
    @Setter
    private String workflowId;

    @Getter
    @Setter
    private String workflowExecutionId;

    @Getter
    @Setter
    private Map<String, Operation> operations;

    @Getter
    @Setter
    private String status;

    @Getter
    @Setter
    private String subStatus;

}