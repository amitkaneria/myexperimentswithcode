package com.workorder.executor.models;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import lombok.*;

import java.util.Map;

@EqualsAndHashCode
@ToString
@Builder
@JsonAutoDetect
public class Request {

    @Getter
    @Setter
    private String requestId;

    @Getter
    @Setter
    private String url;

    //    private Authentication auth;

    @Getter
    @Setter
    private String body;

    @Getter
    @Setter
    private Map<String, String> headers;

}