package com.works.octoflow.depot.models;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import lombok.*;
import org.springframework.hateoas.ResourceSupport;

@EqualsAndHashCode
@ToString
@JsonAutoDetect
@NoArgsConstructor
@AllArgsConstructor
public class Artifact extends ResourceSupport {

    @Getter
    @Setter
    private String name;

    @Getter
    @Setter
    private String type;

}