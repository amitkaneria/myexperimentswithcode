package com.works.octoflow.depot.models;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import lombok.*;
import org.springframework.hateoas.ResourceSupport;

import java.util.ArrayList;
import java.util.List;

@EqualsAndHashCode
@ToString
@JsonAutoDetect
@NoArgsConstructor
@AllArgsConstructor
public class ArtifactList extends ResourceSupport {

    @Getter
    @Setter
    private List<Artifact> artifacts = new ArrayList<>();

}