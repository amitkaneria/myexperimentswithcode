package com.works.octoflow.depot.controller;

import com.works.octoflow.depot.models.Artifact;
import com.works.octoflow.depot.models.ArtifactList;
import com.works.octoflow.depot.models.Greeting;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.springframework.hateoas.Link;
import org.springframework.hateoas.mvc.ControllerLinkBuilder;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@RequestMapping(value = "/api/octoflow/depot/")
@RestController
public class DepotController {

    static List<Artifact> artifacts = null;
    static{
        artifacts = new ArrayList<>();

//        //Adding self link employee collection resource
//        Link selfLink = ControllerLinkBuilder
//                .linkTo(ControllerLinkBuilder
//                        .methodOn(DepotController.class).getAnArtifact(id))
//                .withSelfRel();
//        artifact.add(selfLink);


        Artifact workflow1 = new Artifact("workflow1", "workflow");
        workflow1.add(ControllerLinkBuilder
                .linkTo(ControllerLinkBuilder.methodOn(DepotController.class).getAnArtifact(workflow1.getName()))
                .slash(workflow1.getName())
                .withSelfRel());
        artifacts.add(workflow1);

        Artifact workflow2 = new Artifact("workflow2", "workflow");
        workflow2.add(ControllerLinkBuilder
                .linkTo(ControllerLinkBuilder.methodOn(DepotController.class).getAnArtifact(workflow2.getName()))
                .slash(workflow2.getName())
                .withSelfRel());
        artifacts.add(workflow2);

        Artifact operation1 = new Artifact("operation1", "workflow");
        operation1.add(ControllerLinkBuilder
                .linkTo(ControllerLinkBuilder.methodOn(DepotController.class).getAnArtifact(operation1.getName()))
                .slash(operation1.getName())
                .withSelfRel());
        artifacts.add(operation1);

        Artifact operation2 = new Artifact("operation2", "workflow");
        operation2.add(ControllerLinkBuilder
                .linkTo(ControllerLinkBuilder.methodOn(DepotController.class).getAnArtifact(operation2.getName()))
                .slash(operation2.getName())
                .withSelfRel());
        artifacts.add(operation2);

    }

    @ApiOperation(value = "/artifacts", response = Greeting.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Successfully retrieved list"),
            @ApiResponse(code = 401, message = "You are not authorized to view the resource"),
            @ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
            @ApiResponse(code = 404, message = "The resource you were trying to reach is not found")
    }
    )
    @RequestMapping(value = "/artifacts", method= RequestMethod.GET, produces = "application/json")
    public HttpEntity<ArtifactList> artifacts(
            @RequestParam(value = "type", required = false) String type) {

        List<Artifact> filteredListArtifacts = artifacts;
        if(type != null){
            filteredListArtifacts = filteredListArtifacts.stream().filter(p -> p.getType().equalsIgnoreCase(type)).collect(Collectors.toList());
        }

        //Adding self link employee collection resource
        Link selfLink = ControllerLinkBuilder
                .linkTo(ControllerLinkBuilder
                        .methodOn(DepotController.class).artifacts(type))
                .withSelfRel();
        ArtifactList artifactList = new ArtifactList(filteredListArtifacts);
        artifactList.add(selfLink);

        return new ResponseEntity<>(artifactList, HttpStatus.OK);
    }

    @ApiOperation(value = "/artifacts/{id}", response = Greeting.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Successfully retrieved list"),
            @ApiResponse(code = 401, message = "You are not authorized to view the resource"),
            @ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
            @ApiResponse(code = 404, message = "The resource you were trying to reach is not found")
    }
    )
    @RequestMapping(value = "/artifacts/{id}", method= RequestMethod.GET, produces = "application/json")
    public HttpEntity<Artifact> getAnArtifact(
            @PathVariable(value = "id") String id) {

        Optional<Artifact> first = artifacts.stream().filter(p -> p.getName().equalsIgnoreCase(id)).findFirst();
        Artifact artifact = first.get();

        //Adding self link employee collection resource
        Link selfLink = ControllerLinkBuilder
                .linkTo(ControllerLinkBuilder
                        .methodOn(DepotController.class).getAnArtifact(id))
                .withSelfRel();
        artifact.add(selfLink);

        return new ResponseEntity<>(artifact, HttpStatus.OK);
    }
}